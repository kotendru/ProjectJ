public class Samsung extends Product{
    public Samsung(String title, double price) {
        super(title, price);
    }
    @Override
    public void showInfo() {
        System.out.println("Тип данных Самсунг");
        System.out.println(title);
        System.out.println(price);
    }

}
