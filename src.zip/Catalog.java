import java.util.List;

public class Catalog {
    public String name;
    public List<Category> categories;
    private static int counter = 0;

    Catalog(String name, List<Category> categories) {
        this.name = name;
        this.categories = categories;
        counter += 1;
    }

    void addCategory(Category category) {
        categories.add(category);
    }

    void printCategory() {
        System.out.println("Категория: " + name + "Подкатегории: ");
        for (int i = 0; i < categories.size(); i++) {
            System.out.print(categories.get(i).getName());
        }
    }
}
