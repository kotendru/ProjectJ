public class Aifon extends Product{
    public Aifon(String title, double price) {
        super(title, price);
    }
    @Override
    public void showInfo() {
        System.out.println("Тип данных Айфон");
        System.out.println(title);
        System.out.println(price);
    }

}
