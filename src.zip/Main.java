import java.util.List;
import java.util.Scanner;

// Класс product добавить новый абстракт метод showInfo
// В уноследованных классах переопределить метод
// Создать несколько разных объектов разных типов и обернуть их списком и создать метод для добавления
// С помощью метода showInfo зациклить и показать список из вашего списка

public class Main {
    public static void main(String[] args) {
        Category category1 = new Category("Электроника");
        category1.addCategory(new Aifon("Айфон11", 11000));
        category1.addCategory(new Samsung("Самсунг самса", 14880));
        category1.addCategory(new Redmi("Редми t1000", 1000000));
        category1.printCategory();
        System.out.println();
        category1.printProduct(1);

    }
}