import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 3; i++) {
            Category new_category = new Category(scanner.nextLine(), Garden(scanner.nextLine(), Integer.parseInt(scanner.nextLine())));
        }
        Catalog catalog = new Catalog("Электроника", List.of());


    }
}