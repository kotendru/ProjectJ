public class Redmi extends Product{
    public Redmi(String title, double price) {
        super(title, price);
    }
    @Override
    public void showInfo() {
        System.out.println("Тип данных Редми");
        System.out.println(title);
        System.out.println(price);
    }

}
