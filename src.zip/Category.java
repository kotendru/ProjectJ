import java.util.ArrayList;
import java.util.List;

public class Category {
    private String name;
    public List<Product> products = new ArrayList<>();
    private static int counter = 0;

    Category(String name) {
        this.name = name;
        counter += 1;
    }

    Category(String name, List<Product> products) {
        this.name = name;
        this.products = products;
        counter += 1;
    }

    void addCategory(Product product) {
        products.add(product);
    }

    void printProduct(int index) {
        this.products.get(index).showInfo();
    }

    void printCategory() {
        System.out.println("Категория: " + name + "\nПодкатегории: ");
        for (int i = 0; i < products.size(); i++) { System.out.print(products.get(i).getTitle() + "\n"); }
    }
}
