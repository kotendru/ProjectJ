import java.util.List;

public class Category {
    public String name;
    public List<Product> products;
    private static int counter = 0;

    Category(String name, List<Product> products) {
        this.name = name;
        this.products = products;
        counter += 1;
    }

    String getName() {
        return name;
    }


}
